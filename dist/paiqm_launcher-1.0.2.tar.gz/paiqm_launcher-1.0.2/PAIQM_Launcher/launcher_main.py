from . import paiqm_main

paiqm_main()