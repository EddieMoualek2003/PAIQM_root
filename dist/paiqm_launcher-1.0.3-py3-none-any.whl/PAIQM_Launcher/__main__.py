from .game import run

def main():
    """PAIQM."""
    # print("Starting Quantum Dice Game")
    run()

if __name__ == "__main__":
    main()
