from . import paiqm_main

def run():
    paiqm_main.main()